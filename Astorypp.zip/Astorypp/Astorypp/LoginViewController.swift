//
//  ViewController.swift
//  Astorypp
//
//  Created by Hercio Venceslau Silla on 23/04/24.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var masukLabel: UILabel!
    @IBOutlet weak var usernameLabel: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.masukLabel.font = .boldSystemFont(ofSize: self.masukLabel.font.pointSize)
    }


    @IBAction func actionSignIn(_ sender: Any) {
        performSegue(withIdentifier: "goToSecondVC", sender: nil)
        
        // menyimpan data permanen sederhana ke device
        UserDefaults.standard.setValue(self.usernameLabel.text, forKey: "username")
        UserDefaults.standard.setValue(21, forKey: "umurHercio")
    }
}
//
