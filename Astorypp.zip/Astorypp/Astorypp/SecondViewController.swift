//
//  SecondViewController.swift
//  Astorypp
//
//  Created by Hercio Venceslau Silla on 30/04/24.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var welcomeLabel: UILabel!
    @IBOutlet weak var collectionView: UICollectionView!
    
    let models = [
    "Convertible", "Coupe", "Station Wage Klasik",
    "Off Road Klasik", "Sedan Klasik", "Pickup Klasik"
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // Do any additional setup after loading the view.
        
        let layout = UICollectionViewFlowLayout()
//        layout.itemSize = CGSize(width: 120, height: 120)
        collectionView.collectionViewLayout = layout
        
        collectionView.register(MyCollectionViewCell.nib(), forCellWithReuseIdentifier: MyCollectionViewCell.identifier)
        collectionView.delegate = self
        collectionView.dataSource = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        // Ambil data dari database
        let user = UserDefaults.standard.string(forKey: "username")
        let hercio = UserDefaults.standard.integer(forKey: "umurHercio")
        self.welcomeLabel.text = "Hai \(user ?? ""), Apa Model Mobil Klasik Yang Kamu Suka?"
//       navigationController?.navigationBar.topItem?.title = user
//        navigationController?.title = user
        
        
    }
}


extension SecondViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)

        print("You tapped me")
    }
}

extension SecondViewController: UICollectionViewDataSource{

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 6
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: MyCollectionViewCell.identifier, for: indexPath) as! MyCollectionViewCell

        cell.configure(with: UIImage(named: "car")!)
        
        //nama setiap label cell
        cell.NamaLabel.text = models[indexPath.row]
        

        return cell
    }
}

extension SecondViewController: UICollectionViewDelegateFlowLayout{

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: self.view.frame.width * 0.4, height: self.view.frame.width * 0.4)
    }
}

