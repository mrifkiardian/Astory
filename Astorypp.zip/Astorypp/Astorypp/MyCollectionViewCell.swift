//
//  MyCollectionViewCell.swift
//  Astorypp
//
//  Created by Hercio Venceslau Silla on 30/04/24.
//

import UIKit

class MyCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var NamaLabel: UILabel!
    @IBOutlet weak var carModel: UILabel!
    @IBOutlet var imageView: UIImageView!
    
    static let identifier = "MyCollectionViewCell"
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    public func configure(with image: UIImage){
        imageView.image = image
    }
    
    static func nib() -> UINib {
        return UINib(nibName: "MyCollectionViewCell", bundle: nil)
    }

}
